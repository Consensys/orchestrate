#!/usr/bin/env sh

redis-server /etc/redis/redis.conf &
sleep 2
stunnel

